package javaiscoffee.groomy.ide.board;

/**
 * Finish
 */
public enum BoardStatus {
    /**
     * ACTIVE = 정상 상태
     * DELETE = 삭제 상태
     */
    ACTIVE, DELETE;
}
